package com.aa.a.reviewtalent.view;

import androidx.lifecycle.ViewModel;

public class LottieViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
