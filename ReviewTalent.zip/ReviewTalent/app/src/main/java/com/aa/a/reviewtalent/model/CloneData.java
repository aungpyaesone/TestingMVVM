package com.aa.a.reviewtalent.model;

public class CloneData {
    public String  title,description;

    public CloneData() {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
