package com.aa.a.reviewtalent.view;

import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.aa.a.reviewtalent.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LottieFragment extends Fragment {

    private LottieViewModel mViewModel;

    public @BindView(R.id.editText)
    EditText something;

    public @BindView(R.id.btn_send)
    Button send;

    public @BindView(R.id.textView)
    TextView textView;

    public static LottieFragment newInstance() {
        return new LottieFragment();
    }

    public   MyData Data;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Data = (MyData) getActivity();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.lottie_fragment, container, false);
        ButterKnife.bind(this,v);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(LottieViewModel.class);
        // TODO: Use the ViewModel
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Data.sendData(something.getText().toString().trim());
            }
        });
    }

    public interface MyData{
        void sendData(String message);
    }

}
