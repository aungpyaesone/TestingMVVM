package com.aa.a.reviewtalent.Adapter;

import com.aa.a.reviewtalent.view.AcceptData;
import com.aa.a.reviewtalent.view.FragmentThree;
import com.aa.a.reviewtalent.view.LottieFragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position)
        {
            case 0:
                return LottieFragment.newInstance();
            case 1:
                return AcceptData.newInstance();
            case 2:
                return FragmentThree.newInstance();

            default :
                return LottieFragment.newInstance();

        }

    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position)
        {
            case 0:
                return "LottieAni";

            case 1:
                return "AcceptData";

            case 2:
                return "RecAnni";


            default :
                return "LottieAni";
        }

    }
}
